# Future Code SolarQuote v1.0.0 — Android native source

**Package**: `com.futurecode.solarquote` | **minSdk** 26 | **targetSdk** 35

Native Kotlin Android app with zero runtime third-party dependencies. Pages: Appliance List, Battery Runtime, PV Panel Estimate, Inverter Continuous/Surge Power Check, Customer MMK Quotation, Save/Load/Delete offline SQLite projects, and Android PDF document export. App icon combines a stylized Future Code **F**, sunshine and a PV-panel grid; it is a new vector interpretation, **not an exact reproduction of an unavailable original logo**.

## Build
Install Android Studio and SDK Platform 35, JDK 17 and Android Gradle Plugin dependencies. Open the root directory, allow Gradle sync, then run `gradle assembleDebug` (or via Android Studio). For production create a **private release keystore** and signed release with Android Studio; never commit signing secrets. No pre-existing signing lineage is claimed.

## Important field-engineering boundaries
Battery energy (AC-side Wh) = Ah × nominal V × usable DoD × inverter efficiency. Runtime = energy ÷ (AC load + standby W). PV array minimum Wp = AC energy/day ÷ (peak sun hours × system performance ratio). This is preliminary energy sizing, not certified protection or wiring design; derating, BMS C-rate, discharge profile, site survey, shading, battery aging, seasonal irradiation, PV string voltage, grounding, and protections require on-site assessment. Inverter check tests only specified continuous and surge Watt limits.

## Testing
Pure Kotlin engine test runner: `kotlinc app/src/main/java/com/futurecode/solarquote/Engineering.kt tests/EngineChecks.kt -include-runtime -d /tmp/solarquote-tests.jar && java -jar /tmp/solarquote-tests.jar`. Run Android instrumentation and real-device QA before calling app production-ready.

## Missing from this version
Compose UI and Room/DataStore were proposed but this zero-extra-dependency build uses native Android views and SQLiteOpenHelper. PDF export is single page, with a cap for lengthy item lists. No online sync, external solar prices, or monitoring. This project is source deliverable, **not a compiled/signed APK** without an Android SDK and Gradle distribution.

## APK build (free GitHub Actions)
Upload the **contents of this directory** (not the outer folder) to a GitHub repository with a `main` branch. In GitHub, open **Actions > Build SolarQuote Android APK > Run workflow**. On a successful run, download artifact `FutureCodeSolarQuote-v1.0.0-debug-apk`, unzip it and install `app-debug.apk` on a test device. This is a **debug-signed test APK**, not a production-signed release. GitHub Actions execution and actual Android-device testing remain pending until workflow runs successfully.

For local build: install Android Studio (JDK 17, Android SDK 35), open this project, then run `gradle :app:assembleDebug` with Gradle 8.10.2. A release signing key must be securely generated and retained by the owner for consistent future upgrades.
