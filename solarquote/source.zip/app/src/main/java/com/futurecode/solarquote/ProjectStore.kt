package com.futurecode.solarquote

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class ProjectStore(ctx: Context): SQLiteOpenHelper(ctx, "solarquote.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT NOT NULL, data TEXT NOT NULL, updated INTEGER NOT NULL)") }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun save(id: Long?, customer: String, json: JSONObject): Long {
        val values = ContentValues().apply { put("customer", customer); put("data", json.toString()); put("updated", System.currentTimeMillis()) }
        return if (id == null) writableDatabase.insertOrThrow("projects", null, values) else { writableDatabase.update("projects", values, "id=?", arrayOf(id.toString())); id }
    }
    fun list(): List<Triple<Long,String,Long>> {
        val result = mutableListOf<Triple<Long,String,Long>>()
        readableDatabase.rawQuery("SELECT id,customer,updated FROM projects ORDER BY updated DESC", null).use { c -> while(c.moveToNext()) result += Triple(c.getLong(0),c.getString(1),c.getLong(2)) }
        return result
    }
    fun read(id: Long): JSONObject? = readableDatabase.rawQuery("SELECT data FROM projects WHERE id=?", arrayOf(id.toString())).use { c -> if(c.moveToFirst()) JSONObject(c.getString(0)) else null }
    fun delete(id: Long) { writableDatabase.delete("projects", "id=?", arrayOf(id.toString())) }
}
