package com.futurecode.solarquote

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var store: ProjectStore
    private var activeProject: Long? = null
    private var customer = ""
    private var phone = ""
    private val appliances = mutableListOf<Appliance>()
    private val quoteItems = mutableListOf<QuoteItem>()
    private var batteryAh=100.0; private var voltage=12.8; private var dod=.8; private var eff=.9; private var standby=0.0
    private var sunHours=4.5; private var solarEff=.8; private var panelW=550.0
    private var inverterRated=2000.0; private var inverterSurge=4000.0; private var loadSurge=0.0
    private var installation=0.0; private var margin=0.0
    private val df=DecimalFormat("#,##0.##")
    private val blue=Color.rgb(7,71,151)
    private val pendingPdf=1001
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); store=ProjectStore(this); home(); UpdateManager(this).check() }
    private fun layout(title: String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,20,18,12); setBackgroundColor(Color.rgb(246,249,253)) }
        setContentView(ScrollView(this).apply { addView(root) })
        val banner=TextView(this).apply { text="☀  FUTURE CODE  |  SolarQuote"; textSize=21f; setTextColor(blue); setPadding(0,0,0,14) }
        root.addView(banner)
        val bar=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("Home","Load","Battery","Solar","Quote","Saved").forEach { item ->
            val btn=Button(this).apply { text=item; textSize=9f; minWidth=0; minimumWidth=0; setPadding(1,0,1,0); setOnClickListener { when(item) { "Home"->home();"Load"->loadPage();"Battery"->batteryPage();"Solar"->solarPage();"Quote"->quotePage();else->projectsPage() } } }
            bar.addView(btn,LinearLayout.LayoutParams(0,48,1f))
        }
        root.addView(bar)
        headline(title)
    }
    private fun headline(s:String) { root.addView(TextView(this).apply { text=s; textSize=22f; setTextColor(blue); setPadding(0,15,0,12) }) }
    private fun note(s:String) { root.addView(TextView(this).apply { text=s; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,8,0,12) }) }
    private fun field(label:String, value:String, change:(String)->Unit):EditText {
        root.addView(TextView(this).apply { text=label; textSize=15f; setTextColor(Color.DKGRAY); setPadding(0,8,0,0) })
        return EditText(this).apply { setSingleLine(true); setText(value); setSelectAllOnFocus(true); addTextChangedListener(object: android.text.TextWatcher {
            override fun beforeTextChanged(s:CharSequence?, start:Int,count:Int,after:Int) {}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int) { change(s.toString()) }
            override fun afterTextChanged(s:android.text.Editable?) {}
        }); root.addView(this) }
    }
    private fun numeric(label:String, valNow:Double, change:(Double)->Unit) = field(label, valNow.toString()) { change(it.toDoubleOrNull() ?: Double.NaN) }.apply { inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
    private fun action(label:String, run:()->Unit) { root.addView(Button(this).apply { text=label; setOnClickListener { try { run() } catch(e:Exception) { Toast.makeText(this@MainActivity,e.message ?: "Invalid input",Toast.LENGTH_LONG).show() } } }) }
    private fun format(d:Double)=df.format(d)
    private fun requireFinite(vararg v:Double) { require(v.all { it.isFinite() }) { "Enter valid numbers in every field" } }
    private fun home() { layout("Plan · Calculate · Quote · Offline")
        note("Myanmar solar preliminary sizing and quotations. Customer projects stay on this phone. Internet is used only to check for optional app updates.")
        note("1. Add appliances  2. Estimate battery and panels  3. Prepare quotation  4. Save or export PDF")
        action("CHECK FOR APP UPDATES") { UpdateManager(this).check(force = true) }
        action("START — Add Appliances") {loadPage()}
        action("Open Saved Customer Projects") {projectsPage()}
        note("⚠ Preliminary estimates only. A qualified installer must verify BMS discharge current, inverter surge, protection devices, cable sizing, grounding, shading and manufacturer specifications.")
    }
    private fun loadPage() { layout("Appliance & Load Calculator")
        var name="LED Bulb"; var watts=12.0; var qty=1.0; var hours=5.0
        field("Appliance name",name){name=it}; numeric("Rated power (W)",watts){watts=it}; numeric("Quantity",qty){qty=it}; numeric("Hours used per day (0–24)",hours){hours=it}
        action("+ ADD APPLIANCE") { requireFinite(watts,qty,hours); require(watts>=0 && qty>=1 && qty%1.0==0.0 && hours in 0.0..24.0); appliances += Appliance(name,watts,qty.toInt(),hours); loadPage() }
        appliances.forEachIndexed { i,a -> action("✕  ${a.name} ×${a.quantity}  ${format(a.watts*a.quantity)} W · ${format(a.watts*a.quantity*a.hoursPerDay)} Wh/day") { appliances.removeAt(i);loadPage() } }
        note("Continuous connected load: ${format(Engineering.peakWatts(appliances))} W\nDaily energy: ${format(Engineering.dailyWh(appliances))} Wh/day")
        action("CONTINUE — Battery") {batteryPage()}
    }
    private fun batteryPage() { layout("Battery Backup Estimator")
        var manualLoad= if(appliances.isEmpty()) 100.0 else Engineering.peakWatts(appliances)
        numeric("AC continuous load (W)",manualLoad){manualLoad=it}
        numeric("Battery capacity (Ah)",batteryAh){batteryAh=it}
        numeric("Battery nominal voltage (V)",voltage){voltage=it}
        numeric("Usable depth of discharge (%, LiFePO4 commonly 80%; lead-acid often 50%)",dod*100){dod=it/100}
        numeric("Inverter efficiency (%)",eff*100){eff=it/100}
        numeric("Inverter standby/self-consumption (W)",standby){standby=it}
        action("CALCULATE RUNTIME") {
            requireFinite(manualLoad,batteryAh,voltage,dod,eff,standby)
            val h=Engineering.runtimeHours(manualLoad,batteryAh,voltage,dod,eff,standby)
            val wh=Engineering.usableAcWh(batteryAh,voltage,dod,eff)
            note("Estimated runtime: ${format(h)} hours\nUsable delivered energy: ${format(wh)} Wh\nBattery nominal: ${format(batteryAh*voltage)} Wh")
        }
        action("CONTINUE — Solar") {solarPage()}
        note("Use exact manufacturer limits. Battery chemistry presets are guidance, not certified settings. Include aging, temperature and discharge limits in real-world design.")
    }
    private fun solarPage() { layout("Solar Panels & Inverter")
        val fromLoad=Engineering.dailyWh(appliances)
        var daily=if (fromLoad>0) fromLoad else 4000.0
        var cont=if(appliances.isNotEmpty()) Engineering.peakWatts(appliances) else 650.0
        numeric("Required AC energy (Wh/day)",daily){daily=it}
        numeric("Peak sun hours (hours/day)",sunHours){sunHours=it}
        numeric("System performance ratio / efficiency (%)",solarEff*100){solarEff=it/100}
        numeric("Individual panel nameplate rating (W)",panelW){panelW=it}
        numeric("Continuous connected load (W)",cont){cont=it}
        numeric("Estimated simultaneous start surge (W)",loadSurge){loadSurge=it}
        numeric("Inverter continuous AC rating (W)",inverterRated){inverterRated=it}
        numeric("Inverter surge rating (W)",inverterSurge){inverterSurge=it}
        action("CALCULATE SOLAR + INVERTER CHECK") {
            requireFinite(daily,sunHours,solarEff,panelW,cont,loadSurge,inverterRated,inverterSurge)
            val required=Engineering.panelRequiredW(daily,sunHours,solarEff); val n=Engineering.numberOfPanels(required,panelW)
            val ok=Engineering.inverterCheck(cont, maxOf(cont,loadSurge),inverterRated,inverterSurge)
            note("PV minimum: ${format(required)} Wp\nPanels: $n × ${format(panelW)} Wp = ${format(n*panelW)} Wp\nInverter: ${if(ok) "PASS (power ratings only)" else "FAIL — check ratings"}")
        }
        note("PV energy is an average estimate: shading, monsoon/cloud, panel orientation, wiring/string voltage, temperature and site survey are not verified. Motor starting surge must be checked against manufacturer data.")
        action("CONTINUE — Quotation") {quotePage()}
    }
    private fun quotePage() { layout("Customer Quotation · MMK")
        field("Customer name",customer){customer=it};field("Phone / address",phone){phone=it}
        var product="Solar Panel 550W";var qty=1.0;var price=0.0
        field("Product / service",product){product=it}; numeric("Quantity",qty){qty=it}; numeric("Unit price (MMK)",price){price=it}
        action("+ ADD QUOTATION ITEM") {requireFinite(qty,price);require(qty>0 && qty%1.0==0.0 && price>=0); quoteItems+=QuoteItem(product,qty.toInt(),price);quotePage()}
        quoteItems.forEachIndexed { i,v -> action("✕ ${v.name} ×${v.quantity} = ${format(v.quantity*v.unitPrice)} Ks") {quoteItems.removeAt(i);quotePage()} }
        numeric("Installation / transport fee (MMK)",installation){installation=it}
        numeric("Profit margin / markup on cost (%)",margin){margin=it}
        action("CALCULATE TOTAL") { requireFinite(installation,margin); note("Quotation total: ${format(Engineering.quoteTotal(quoteItems,installation,margin))} MMK") }
        action("SAVE PROJECT (offline)") { save();Toast.makeText(this,"Project saved",Toast.LENGTH_SHORT).show() }
        action("EXPORT MYANMAR PDF") { require(quoteItems.isNotEmpty()) {"Add quotation items"};requireFinite(installation,margin); val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type="application/pdf";putExtra(Intent.EXTRA_TITLE,"SolarQuote_${System.currentTimeMillis()}.pdf") };startActivityForResult(intent,pendingPdf) }
    }
    private fun state():JSONObject = JSONObject().apply {
        put("customer",customer);put("phone",phone);put("batteryAh",batteryAh);put("voltage",voltage);put("dod",dod);put("eff",eff);put("standby",standby);put("sunHours",sunHours);put("solarEff",solarEff);put("panelW",panelW);put("inverterRated",inverterRated);put("inverterSurge",inverterSurge);put("loadSurge",loadSurge);put("installation",installation);put("margin",margin)
        put("appliances",JSONArray().also { a->appliances.forEach {a.put(JSONObject().put("name",it.name).put("watts",it.watts).put("quantity",it.quantity).put("hours",it.hoursPerDay))} })
        put("items",JSONArray().also { a->quoteItems.forEach { a.put(JSONObject().put("name",it.name).put("quantity",it.quantity).put("price",it.unitPrice)) } })
    }
    private fun save() { requireFinite(batteryAh,voltage,dod,eff,standby,sunHours,solarEff,panelW,inverterRated,inverterSurge,loadSurge,installation,margin);activeProject=store.save(activeProject,customer.ifBlank {"Customer (untitled)"},state()) }
    private fun restore(id:Long) { val j=store.read(id) ?: return;activeProject=id
        customer=j.optString("customer");phone=j.optString("phone");batteryAh=j.optDouble("batteryAh",100.0);voltage=j.optDouble("voltage",12.8);dod=j.optDouble("dod",.8);eff=j.optDouble("eff",.9);standby=j.optDouble("standby",0.0)
        sunHours=j.optDouble("sunHours",4.5);solarEff=j.optDouble("solarEff",.8);panelW=j.optDouble("panelW",550.0);inverterRated=j.optDouble("inverterRated",2000.0);inverterSurge=j.optDouble("inverterSurge",4000.0);loadSurge=j.optDouble("loadSurge",0.0);installation=j.optDouble("installation",0.0);margin=j.optDouble("margin",0.0)
        appliances.clear();j.optJSONArray("appliances")?.let {a->for(i in 0 until a.length()){ val x=a.getJSONObject(i);appliances+=Appliance(x.getString("name"),x.getDouble("watts"),x.getInt("quantity"),x.getDouble("hours")) }}
        quoteItems.clear();j.optJSONArray("items")?.let {a->for(i in 0 until a.length()){ val x=a.getJSONObject(i);quoteItems+=QuoteItem(x.getString("name"),x.getInt("quantity"),x.getDouble("price")) }}
        quotePage()
    }
    private fun projectsPage() {layout("Saved Projects (this device)");action("New Customer Project") {activeProject=null;customer="";phone="";appliances.clear();quoteItems.clear();quotePage()}
        store.list().forEach { (id,name,_) -> action("OPEN  #$id  $name") {restore(id)}; action("DELETE #$id $name") { android.app.AlertDialog.Builder(this).setTitle("Delete project?").setMessage(name).setPositiveButton("Delete") { _,_->store.delete(id);projectsPage() }.setNegativeButton("Cancel",null).show() } }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {super.onActivityResult(requestCode,resultCode,data);if(requestCode==pendingPdf && resultCode==RESULT_OK) {data?.data?.let { try { exportPdf(it);Toast.makeText(this,"PDF saved",Toast.LENGTH_LONG).show() } catch(e:Exception) {Toast.makeText(this,"PDF error: ${e.message}",Toast.LENGTH_LONG).show()} } } }
    private fun exportPdf(uri: Uri) {
        val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val canvas=page.canvas
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.BLACK; textSize=14f; typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.NORMAL) }
        var y=45f
        fun line(s:String, size:Float=12f) {p.textSize=size;canvas.drawText(s,40f,y,p);y+=size+12f}
        line("FUTURE CODE SOLARQUOTE",20f);line("Customer / ဝယ်ယူသူ: $customer");line("Contact / ဆက်သွယ်ရန်: $phone");line("Date: ${java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(java.util.Date())}")
        y+=12f;line("Quotation / ဈေးနှုန်းလွှာ",17f)
        quoteItems.forEachIndexed { i,item ->
            if(y>740f) { line("Additional items omitted — please shorten quotation");return@forEachIndexed }
            val amt=item.quantity*item.unitPrice
            line("${i+1}. ${item.name.take(50)}  x${item.quantity}  ${format(amt)} MMK")
        }
        y+=10f;line("Installation: ${format(installation)} MMK");line("Markup: ${format(margin)}%");line("TOTAL: ${format(Engineering.quoteTotal(quoteItems,installation,margin))} MMK",17f)
        y+=20f;line("Preliminary quotation only. Installation subject to site survey.",11f)
        line("PV, BMS, cable, breakers and surge must be checked by a qualified technician.",10f)
        doc.finishPage(page)
        try {contentResolver.openOutputStream(uri)?.use {doc.writeTo(it)} ?: error("Cannot open output file") } finally {doc.close()}
    }
}
