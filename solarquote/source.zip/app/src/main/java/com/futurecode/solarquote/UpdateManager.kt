package com.futurecode.solarquote

import android.app.Activity
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

/** Consent-driven, certificate-checked update service. No silent installations. */
class UpdateManager(private val activity: Activity) {
    companion object {
        const val UPDATE_JSON = "https://raw.githubusercontent.com/futurecode064-cyber/AI-Recap-GitHub/main/solarquote/latest.json"
        private const val CHECK_INTERVAL_MS = 24L * 60 * 60 * 1000
        private const val MAX_APK_BYTES = 120L * 1024 * 1024
        private const val MIME_APK = "application/vnd.android.package-archive"
        private const val AUTHORITY = "com.futurecode.solarquote.update"
    }
    private val ui = Handler(Looper.getMainLooper())
    private val prefs = activity.getSharedPreferences("solarquote_updates", 0)
    private data class Release(val versionCode: Long, val versionName: String, val notes: String,
                               val url: String, val sha256: String)

    fun check(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - prefs.getLong("last_successful_check", 0L) < CHECK_INTERVAL_MS) return
        Thread {
            try {
                val release = parseRelease(readHttps(UPDATE_JSON, 256 * 1024).toString(Charsets.UTF_8))
                prefs.edit().putLong("last_successful_check", System.currentTimeMillis()).apply()
                if (release.versionCode <= installedVersion()) {
                    if (force) ui.post { if (!activity.isFinishing) toast("SolarQuote is up to date") }
                    return@Thread
                }
                ui.post {
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    AlertDialog.Builder(activity).setTitle("SolarQuote Update ${release.versionName}")
                        .setMessage("New version available.\n\n${release.notes}\n\nDownload and install this update?")
                        .setNegativeButton("Later", null)
                        .setPositiveButton("Download Update") { _, _ -> download(release) }.show()
                }
            } catch (e: Exception) {
                // Offline usability is preserved: silent checks never interrupt calculations.
                if (force) ui.post { if (!activity.isFinishing) toast("Update check unavailable: ${e.message}") }
            }
        }.start()
    }

    private fun parseRelease(json: String): Release {
        val j = JSONObject(json)
        require(j.getString("packageName") == activity.packageName) { "Update package mismatch" }
        val code = j.getLong("versionCode")
        require(code > 0) { "Invalid release version" }
        // Allow harmless placeholder metadata with versionCode <= the installed build.
        val url = j.optString("apkUrl")
        val digest = j.optString("sha256").lowercase(Locale.ROOT)
        if (code > installedVersion()) {
            require(url.startsWith("https://")) { "Update must be HTTPS" }
            require(Regex("[a-f0-9]{64}").matches(digest)) { "Invalid APK SHA-256" }
        }
        return Release(code, j.optString("versionName", code.toString()),
            j.optString("notes", "Security and stability fixes").take(900), url, digest)
    }

    @Suppress("DEPRECATION")
    private fun installedVersion(): Long {
        val p = activity.packageManager.getPackageInfo(activity.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()
    }

    private fun download(release: Release) {
        val dialog = ProgressDialog(activity).apply {
            setTitle("Downloading SolarQuote ${release.versionName}")
            setMessage("Verifying download and app signature…")
            setCancelable(false)
            show()
        }
        Thread {
            val target = File(File(activity.cacheDir, "updates"), "solarquote-update.apk")
            val temp = File(target.parentFile, "solarquote-update.part")
            try {
                require(target.parentFile!!.mkdirs() || target.parentFile!!.isDirectory)
                val digest = MessageDigest.getInstance("SHA-256")
                val connection = openHttps(release.url)
                try {
                    val length = connection.contentLengthLong
                    require(length < 0 || length <= MAX_APK_BYTES) { "APK exceeds download limit" }
                    var total = 0L
                    connection.inputStream.use { input -> temp.outputStream().use { output ->
                        val buffer = ByteArray(32768)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            total += n
                            require(total <= MAX_APK_BYTES) { "APK exceeds download limit" }
                            output.write(buffer, 0, n)
                            digest.update(buffer, 0, n)
                        }
                    } }
                } finally { connection.disconnect() }
                require(digest.digest().joinToString("") { "%02x".format(it) } == release.sha256) {
                    "APK checksum mismatch"
                }
                require(verifyApk(temp, release.versionCode)) { "APK package, version or signing certificate mismatch" }
                target.delete()
                require(temp.renameTo(target)) { "Unable to prepare downloaded APK" }
                ui.post { dialog.dismiss(); if (!activity.isFinishing) startInstaller(target) }
            } catch (e: Exception) {
                temp.delete()
                ui.post { dialog.dismiss(); if (!activity.isFinishing) toast("Update cancelled: ${e.message}") }
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun verifyApk(file: File, advertisedVersion: Long): Boolean {
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val archive = activity.packageManager.getPackageArchiveInfo(file.absolutePath, flags) ?: return false
        val installed = activity.packageManager.getPackageInfo(activity.packageName, flags)
        val version = if (Build.VERSION.SDK_INT >= 28) archive.longVersionCode else archive.versionCode.toLong()
        if (archive.packageName != activity.packageName || version != advertisedVersion || version <= installedVersion()) return false
        fun certs(info: PackageInfo): Set<String> {
            val signatures = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners else info.signatures
            return signatures?.map { sha256(it.toByteArray()) }?.toSet() ?: emptySet()
        }
        val mine = certs(installed)
        return mine.isNotEmpty() && mine == certs(archive)
    }

    private fun sha256(data: ByteArray) = MessageDigest.getInstance("SHA-256")
        .digest(data).joinToString("") { "%02x".format(it) }

    private fun startInstaller(file: File) {
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(activity).setTitle("Allow SolarQuote updates")
                .setMessage("Android requires you to allow installation from SolarQuote. After granting permission, tap Check for Updates again.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Open Settings") { _, _ ->
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${activity.packageName}")))
                }.show()
            return
        }
        val uri = Uri.parse("content://$AUTHORITY/apk")
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, MIME_APK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { activity.startActivity(intent) }
        catch (e: Exception) { toast("Android installer unavailable: ${e.message}") }
    }

    private fun toast(text: String) { Toast.makeText(activity, text, Toast.LENGTH_LONG).show() }

    private fun readHttps(url: String, limit: Int): ByteArray {
        val conn = openHttps(url)
        return try {
            val out = java.io.ByteArrayOutputStream()
            conn.inputStream.use { input ->
                val buf = ByteArray(8192)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    require(out.size() + n <= limit) { "Manifest too large" }
                    out.write(buf, 0, n)
                }
            }
            out.toByteArray()
        } finally { conn.disconnect() }
    }

    private fun openHttps(address: String): HttpURLConnection {
        var url = URL(address)
        repeat(6) { i ->
            require(url.protocol.equals("https", true)) { "Only HTTPS updates allowed" }
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 20000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "FutureCodeSolarQuote-Android")
            }
            val code = conn.responseCode
            if (code in listOf(301, 302, 303, 307, 308)) {
                val location = conn.getHeaderField("Location") ?: error("Invalid redirect")
                url = URL(url, location)
                conn.disconnect()
            } else {
                require(code == 200) { "HTTP $code" }
                return conn
            }
        }
        error("Too many redirects")
    }
}
