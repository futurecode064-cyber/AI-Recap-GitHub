package com.futurecode.solarquote

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

/** Read-only bridge to Android's package installer; no broad filesystem access. */
class UpdateApkProvider : ContentProvider() {
    override fun onCreate(): Boolean = true
    private fun apk(uri: Uri): File {
        require(uri.scheme == "content" && uri.authority == "com.futurecode.solarquote.update" && uri.path == "/apk")
        val dir = File(requireNotNull(context).cacheDir, "updates")
        return File(dir, "solarquote-update.apk").canonicalFile.also {
            require(it.parentFile == dir.canonicalFile && it.isFile) { "No verified APK available" }
        }
    }
    override fun getType(uri: Uri) = if (uri.path == "/apk") "application/vnd.android.package-archive" else null
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        require(mode == "r") { "Read only" }
        return ParcelFileDescriptor.open(apk(uri), ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val file = apk(uri)
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val cursor = MatrixCursor(cols)
        cursor.addRow(cols.map { when (it) { OpenableColumns.DISPLAY_NAME -> "FutureCodeSolarQuote-update.apk"; OpenableColumns.SIZE -> file.length(); else -> null } })
        return cursor
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
