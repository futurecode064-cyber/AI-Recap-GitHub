package com.futurecode.solarquote

import kotlin.math.ceil

/** All calculations use W, Wh, V, Ah, hours and fraction-valued efficiency. */
object Engineering {
    fun runtimeHours(loadW: Double, batteryAh: Double, voltageV: Double, dod: Double, inverterEfficiency: Double, standbyW: Double = 0.0): Double {
        require(loadW > 0 && batteryAh > 0 && voltageV > 0 && standbyW >= 0)
        require(dod > 0 && dod <= 1 && inverterEfficiency > 0 && inverterEfficiency <= 1)
        return batteryAh * voltageV * dod * inverterEfficiency / (loadW + standbyW)
    }
    fun usableAcWh(batteryAh: Double, voltageV: Double, dod: Double, inverterEfficiency: Double): Double {
        require(batteryAh > 0 && voltageV > 0 && dod > 0 && dod <= 1 && inverterEfficiency > 0 && inverterEfficiency <= 1)
        return batteryAh * voltageV * dod * inverterEfficiency
    }
    fun dailyWh(appliances: List<Appliance>): Double {
        require(appliances.all { it.watts >= 0 && it.quantity >= 0 && it.hoursPerDay in 0.0..24.0 })
        return appliances.sumOf { it.watts * it.quantity * it.hoursPerDay }
    }
    fun peakWatts(appliances: List<Appliance>): Double = appliances.sumOf { it.watts * it.quantity }
    fun panelRequiredW(dailyEnergyWh: Double, peakSunHours: Double, systemEfficiency: Double): Double {
        require(dailyEnergyWh >= 0 && peakSunHours > 0 && systemEfficiency > 0 && systemEfficiency <= 1)
        return dailyEnergyWh / (peakSunHours * systemEfficiency)
    }
    fun numberOfPanels(requiredW: Double, panelW: Double): Int {
        require(requiredW >= 0 && panelW > 0)
        return ceil(requiredW / panelW).toInt()
    }
    fun inverterCheck(continuousW: Double, surgeW: Double, inverterContinuousW: Double, inverterSurgeW: Double): Boolean {
        require(listOf(continuousW,surgeW,inverterContinuousW,inverterSurgeW).all { it >= 0 })
        return continuousW <= inverterContinuousW && surgeW <= inverterSurgeW
    }
    fun quoteTotal(items: List<QuoteItem>, installation: Double, marginPercent: Double): Double {
        require(installation >= 0 && marginPercent >= 0 && items.all { it.quantity >= 0 && it.unitPrice >= 0 })
        return (items.sumOf { it.quantity * it.unitPrice } + installation) * (1 + marginPercent / 100)
    }
}
data class Appliance(val name: String, val watts: Double, val quantity: Int, val hoursPerDay: Double)
data class QuoteItem(val name: String, val quantity: Int, val unitPrice: Double)
