import com.futurecode.solarquote.*
import kotlin.math.abs
fun near(got:Double, expected:Double)=check(abs(got-expected)<1e-8){"Expected $expected, got $got"}
fun main() {
    near(Engineering.runtimeHours(100.0,100.0,12.8,.8,.9),9.216)
    near(Engineering.usableAcWh(100.0,12.8,.8,.9),921.6)
    near(Engineering.dailyWh(listOf(Appliance("Light",12.0,5,5.0))),300.0)
    near(Engineering.panelRequiredW(4000.0,4.5,.8),1111.111111111111)
    check(Engineering.numberOfPanels(1111.111,550.0)==3)
    check(Engineering.inverterCheck(500.0,1500.0,1000.0,2000.0))
    check(!Engineering.inverterCheck(500.0,2500.0,1000.0,2000.0))
    near(Engineering.quoteTotal(listOf(QuoteItem("PV",3,550000.0)),400000.0,10.0),2255000.0)
    for (ah in listOf(50.0,100.0,200.0)) for (load in listOf(50.0,100.0,500.0)) {
      val base=Engineering.runtimeHours(load,ah,25.6,.8,.9)
      check(Engineering.runtimeHours(load,ah*2,25.6,.8,.9)>=base)
      check(Engineering.runtimeHours(load*2,ah,25.6,.8,.9)<=base)
    }
    for (f in listOf<()->Unit>(
      {Engineering.runtimeHours(0.0,100.0,12.8,.8,.9)},
      {Engineering.runtimeHours(100.0,100.0,12.8,1.1,.9)},
      {Engineering.panelRequiredW(4000.0,0.0,.8)},
      {Engineering.numberOfPanels(1000.0,0.0)}
    )) { var thrown=false;try {f()}catch(e:IllegalArgumentException){thrown=true};check(thrown) }
    println("PASS: 8 representative calculations, 9 monotonicity pairs, 4 invalid-input guards")
}
