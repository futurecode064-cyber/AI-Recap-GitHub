# Future Code RentTrack — Android v1.0.1 Source

Native Android Kotlin offline rental management app, extended from the original v1.0 source. Maintains the `com.futurecode.renttrack` application ID and SQLite database structure.

## Features
- Rental asset catalog, maintenance lock, booking overlap protection, rental/return records
- Future Code + RentTrack branded launcher icon
- Background opt-in update and announcement checks via WorkManager (every ~6 h when network is available)
- Android 13+ `POST_NOTIFICATIONS` permission prompt, notification channels and manual notices screen
- Owner-managed release/notice channel: `https://raw.githubusercontent.com/futurecode064-cyber/AI-Recap-GitHub/main/renttrack/channel.json`
- Manual, **user-approved** update install: HTTPS APK download, SHA-256 verification, Android FileProvider, Android installer consent
- No silent APK installation (Android security restriction); no always-on server, FCM, or guaranteed instant pushes

## Compile
Open this folder in Android Studio with Android SDK 35, JDK 17, Gradle 8.9 / Android Gradle Plugin 8.7.3. Run `gradle assembleDebug` for local testing. The Gradle wrapper is not included because it was absent in the original starter source; use Android Studio's installed Gradle or generate a wrapper. Android Studio must be able to download AndroidX dependencies.

**This source has not been compiled or tested on an Android phone in the current environment.** Do not deploy as production without integration tests, device QA, and release signing.

## Keep the original update signing certificate
- App ID: `com.futurecode.renttrack`
- Current source: `versionCode=2`, `versionName=1.0.1`
- Release must have `versionCode` greater than users' installed builds **and** the **same signing certificate**. Original signed keystore/signature was not included in supplied ZIP, so compatibility cannot be established yet.
- Configure secure release signing in Android Studio/CI with a backed-up signing key, never commit the private keystore or passwords.
- The release feed must not point at an APK until real signed APK, SHA-256, installation and compatibility tests have passed.

## Publishing a new version
1. Increment `versionCode` and `versionName`.
2. Run unit/instrumentation tests; install over the last signed release and verify DB preservation.
3. Sign the release with the same persistent keystore. Obtain SHA-256 with `sha256sum RentTrack.apk`.
4. Host the APK at a direct HTTPS download URL accessible to Myanmar users.
5. Update `renttrack/channel.json` in the user-owned public `AI-Recap-GitHub` repository. Fields: `versionCode`, `versionName`, `apkUrl`, `sha256`, `releaseNotes`, `announcements`.
6. After up to six hours (and device OS scheduling delays), the app checks and notifies users who granted notification permission. Tapping prompts download/install. Users can check immediately in the app.

## Sending broadcast notices
Edit the JSON `announcements` array in the same public channel. Add a unique string `id`, `title`, and `body` per notice. Reusing an ID will not re-notify people who received it. This is **poll-based** notification, **not live FCM push**; a user must connect to the internet, and Android may defer WorkManager execution.

## Security/privacy
The app only fetches release/notice JSON and the opted-in update APK. Rental/customer records remain in local SQLite. Do not publish customer data or device tokens in the public feed. The file URL is HTTPS and a signed Android APK is verified with SHA-256 before passing to the Android installer. The actual APK signature must still match the installed app.

## Remaining production blockers
- No Android SDK/Gradle build execution in the current environment.
- No verified old signing certificate or release keystore.
- No compiled APK, physical device test, or live APK hosting yet.
- The existing Future Code downloads site is hosted on a separate platform; integration is not complete.
