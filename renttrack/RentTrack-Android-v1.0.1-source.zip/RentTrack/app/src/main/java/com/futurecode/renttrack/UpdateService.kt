package com.futurecode.renttrack

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** Public read-only release/announcements channel. No customer data is sent to this URL. */
object RentTrackUpdates {
    // Owner-controlled public JSON. Publish APK and set apkUrl/sha256 only after signed release QA.
    const val CHANNEL_URL = "https://raw.githubusercontent.com/futurecode064-cyber/AI-Recap-GitHub/main/renttrack/channel.json"
    private const val PREFS = "renttrack_notifications"
    private const val CHANNEL_UPDATES = "renttrack_updates"
    private const val CHANNEL_NEWS = "renttrack_news"

    data class Release(
        val versionCode: Int,
        val versionName: String,
        val apkUrl: String,
        val sha256: String,
        val notes: String
    ) {
        fun canInstall() = apkUrl.startsWith("https://") && sha256.matches(Regex("[a-fA-F0-9]{64}"))
    }
    data class Notice(val id: String, val title: String, val body: String)
    data class Feed(val release: Release, val notices: List<Notice>)

    fun fetch(): Feed {
        val connection = (URL(CHANNEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "FutureCode-RentTrack-Android")
        }
        try {
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("Feed HTTP ${connection.responseCode}")
            }
            val text = connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                // Avoid unbounded memory use on a malicious feed.
                val sb = StringBuilder()
                val buf = CharArray(2048)
                while (true) {
                    val count = reader.read(buf)
                    if (count < 0) break
                    if (sb.length + count > 128 * 1024) throw IOException("Feed is too large")
                    sb.append(buf, 0, count)
                }
                sb.toString()
            }
            val obj = JSONObject(text)
            val rawNotices = obj.optJSONArray("announcements")
            val notices = mutableListOf<Notice>()
            if (rawNotices != null) {
                for (i in 0 until minOf(20, rawNotices.length())) {
                    val n = rawNotices.optJSONObject(i) ?: continue
                    val id = n.optString("id").trim().take(64)
                    val title = n.optString("title").trim().take(80)
                    val body = n.optString("body").trim().take(300)
                    if (id.isNotEmpty() && title.isNotEmpty() && body.isNotEmpty()) {
                        notices.add(Notice(id, title, body))
                    }
                }
            }
            return Feed(
                Release(
                    versionCode = obj.optInt("versionCode", 0),
                    versionName = obj.optString("versionName", ""),
                    apkUrl = obj.optString("apkUrl", ""),
                    sha256 = obj.optString("sha256", ""),
                    notes = obj.optString("releaseNotes", "").take(1000)
                ),
                notices
            )
        } finally { connection.disconnect() }
    }

    fun schedule(context: Context) {
        createChannels(context)
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val task = PeriodicWorkRequestBuilder<UpdatePollWorker>(6, TimeUnit.HOURS)
            .setConstraints(constraints).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "RentTrackUpdatesAndAnnouncements", ExistingPeriodicWorkPolicy.KEEP, task
        )
    }

    fun createChannels(ctx: Context) {
        val manager = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(
            CHANNEL_UPDATES, "App updates", NotificationManager.IMPORTANCE_DEFAULT
        ))
        manager.createNotificationChannel(NotificationChannel(
            CHANNEL_NEWS, "RentTrack announcements", NotificationManager.IMPORTANCE_DEFAULT
        ))
    }

    private fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun processFeed(ctx: Context, feed: Feed) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!canNotify(ctx)) return // Retry notification when permission becomes available.
        if (feed.release.versionCode > BuildConfig.VERSION_CODE && feed.release.canInstall() &&
            prefs.getInt("last_update", 0) < feed.release.versionCode) {
            notifyUser(ctx, CHANNEL_UPDATES, 1001,
                "RentTrack ${feed.release.versionName} ရရှိပါပြီ",
                "Update ဒေါင်းလုပ်လုပ်ရန် နှိပ်ပါ။ Installation အတွက် ခွင့်ပြုချက်လိုအပ်သည်။")
            prefs.edit().putInt("last_update", feed.release.versionCode).apply()
        }
        val seen = prefs.getStringSet("seen_announcements", emptySet())?.toMutableSet() ?: mutableSetOf()
        for (notice in feed.notices) {
            if (notice.id !in seen) {
                notifyUser(ctx, CHANNEL_NEWS, notice.id.hashCode(), notice.title, notice.body)
                seen.add(notice.id)
            }
        }
        // Keep a bounded history; older IDs may re-notify if republished by the administrator.
        prefs.edit().putStringSet("seen_announcements", seen.toList().takeLast(100).toSet()).apply()
    }

    private fun notifyUser(ctx: Context, channel: String, id: Int, title: String, body: String) {
        val manager = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("from_notification", true)
        }
        val pending = PendingIntent.getActivity(
            ctx, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(pending).setAutoCancel(true).build()
        manager.notify(id, notification)
    }

    /** Download ONLY on an explicit user action. SHA-256 verification is mandatory. */
    fun verifiedDownload(ctx: Context, release: Release): File {
        require(release.canInstall()) { "Invalid HTTPS URL or SHA-256" }
        val folder = File(ctx.cacheDir, "updates")
        if (!folder.exists() && !folder.mkdirs()) throw IOException("Cannot create download folder")
        val apk = File(folder, "RentTrack-${release.versionCode}.apk")
        val digest = MessageDigest.getInstance("SHA-256")
        // Handle cache intentionally: always verify against the published release hash.
        val connection = (URL(release.apkUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 30000
            setRequestProperty("User-Agent", "FutureCode-RentTrack-Android")
            instanceFollowRedirects = true
        }
        try {
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("APK HTTP ${connection.responseCode}")
            }
            val max = 150L * 1024 * 1024
            var total = 0L
            connection.inputStream.use { input ->
                apk.outputStream().use { output ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > max) throw IOException("APK exceeds 150 MB limit")
                        digest.update(buffer, 0, count)
                        output.write(buffer, 0, count)
                    }
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actual.equals(release.sha256, ignoreCase = true)) {
                throw IOException("APK checksum mismatch — update blocked")
            }
            if (total < 1024L) throw IOException("Invalid or empty APK download")
            return apk
        } catch (ex: Exception) {
            apk.delete()
            throw ex
        } finally { connection.disconnect() }
    }
}

class UpdatePollWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            RentTrackUpdates.processFeed(applicationContext, RentTrackUpdates.fetch())
            Result.success()
        } catch (e: IOException) {
            Result.retry()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
