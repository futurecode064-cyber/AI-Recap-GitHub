package com.futurecode.renttrack

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Color
import android.os.Build
import android.net.Uri
import android.provider.Settings
import android.content.pm.PackageManager
import androidx.core.content.FileProvider
import java.io.File
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class RentalDb(ctx: Context): SQLiteOpenHelper(ctx,"renttrack.db",null,1) {
 override fun onCreate(db:SQLiteDatabase) {
  db.execSQL("CREATE TABLE assets(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,rate INTEGER NOT NULL CHECK(rate>=0),maintenance INTEGER NOT NULL DEFAULT 0)")
  db.execSQL("CREATE TABLE rentals(id INTEGER PRIMARY KEY AUTOINCREMENT,asset_id INTEGER NOT NULL,customer TEXT NOT NULL,phone TEXT NOT NULL,start_ms INTEGER NOT NULL,end_ms INTEGER NOT NULL,fee INTEGER NOT NULL CHECK(fee>=0),deposit INTEGER NOT NULL CHECK(deposit>=0),paid INTEGER NOT NULL DEFAULT 0 CHECK(paid>=0),refunded INTEGER NOT NULL DEFAULT 0 CHECK(refunded>=0),status TEXT NOT NULL DEFAULT 'ACTIVE',FOREIGN KEY(asset_id) REFERENCES assets(id))")
  db.execSQL("CREATE INDEX rental_conflicts ON rentals(asset_id,status,start_ms,end_ms)")
 }
 override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int) {}
 fun addAsset(name:String,rate:Long) { writableDatabase.execSQL("INSERT INTO assets(name,rate) VALUES(?,?)",arrayOf(name,rate)) }
 fun assets():List<Asset> { val out= mutableListOf<Asset>(); readableDatabase.rawQuery("SELECT id,name,rate,maintenance FROM assets ORDER BY id DESC",null).use { while(it.moveToNext()) out.add(Asset(it.getLong(0),it.getString(1),it.getLong(2),it.getInt(3)==1)) }; return out }
 fun maintenance(id:Long,on:Boolean) { writableDatabase.execSQL("UPDATE assets SET maintenance=? WHERE id=?",arrayOf(if(on)1 else 0,id)) }
 fun book(asset:Asset,customer:String,phone:String,start:Long,end:Long,fee:Long,deposit:Long):Boolean {
  require(end>start && fee>=0 && deposit>=0)
  val db=writableDatabase; db.beginTransaction()
  try {
   val available=db.rawQuery("SELECT COUNT(*) FROM assets WHERE id=? AND maintenance=0",arrayOf(asset.id.toString())).use { it.moveToFirst();it.getInt(0)==1 }
   val overlap=db.rawQuery("SELECT COUNT(*) FROM rentals WHERE asset_id=? AND status='ACTIVE' AND start_ms<? AND end_ms>?",arrayOf(asset.id.toString(),end.toString(),start.toString())).use { it.moveToFirst();it.getInt(0)>0 }
   if(!available||overlap) return false
   db.execSQL("INSERT INTO rentals(asset_id,customer,phone,start_ms,end_ms,fee,deposit,paid) VALUES(?,?,?,?,?,?,?,?)",arrayOf(asset.id,customer,phone,start,end,fee,deposit,fee+deposit))
   db.setTransactionSuccessful();return true
  } finally {db.endTransaction()}
 }
 fun rentals():List<Rental> { val out= mutableListOf<Rental>(); readableDatabase.rawQuery("SELECT r.id,a.name,r.customer,r.phone,r.start_ms,r.end_ms,r.fee,r.deposit,r.paid,r.refunded,r.status FROM rentals r JOIN assets a ON a.id=r.asset_id ORDER BY r.id DESC",null).use { while(it.moveToNext()) out.add(Rental(it.getLong(0),it.getString(1),it.getString(2),it.getString(3),it.getLong(4),it.getLong(5),it.getLong(6),it.getLong(7),it.getLong(8),it.getLong(9),it.getString(10))) };return out }
 fun complete(id:Long) { val db=writableDatabase;db.beginTransaction();try { db.execSQL("UPDATE rentals SET status='RETURNED',refunded=deposit WHERE id=? AND status='ACTIVE'",arrayOf(id));db.setTransactionSuccessful() }finally{db.endTransaction()} }
}
data class Asset(val id:Long,val name:String,val rate:Long,val maintenance:Boolean)
data class Rental(val id:Long,val asset:String,val customer:String,val phone:String,val start:Long,val end:Long,val fee:Long,val deposit:Long,val paid:Long,val refunded:Long,val status:String)
class MainActivity:Activity() {
 private lateinit var db:RentalDb; private lateinit var root:LinearLayout
 private var pendingApk:File? = null
 private val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US)
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  db=RentalDb(this)
  RentTrackUpdates.schedule(applicationContext)
  home()
  if (intent?.getBooleanExtra("from_notification", false) == true) checkForUpdates()
 }
 private fun base(title:String) {root=LinearLayout(this).apply {orientation=1;setPadding(20,20,20,20);setBackgroundColor(Color.rgb(246,248,250))};val scroll=ScrollView(this);scroll.addView(root);setContentView(scroll);text(title,25);button("Dashboard",{home()})}
 private fun text(s:String,size:Int=16) {root.addView(TextView(this).apply {text=s;textSize=size.toFloat();setTextColor(Color.rgb(20,37,50));setPadding(0,12,0,12)})}
 private fun button(s:String,action:()->Unit) {root.addView(Button(this).apply {text=s;setOnClickListener {action()} })}
 private fun input(hint:String,number:Boolean=false):EditText {val v=EditText(this).apply {this.hint=hint;if(number) inputType=2};root.addView(v);return v}
 private fun alert(s:String) {Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
 private fun home() {base("Future Code RentTrack");val logo=ImageView(this).apply{setImageResource(R.drawable.renttrack_logo);adjustViewBounds=true;maxHeight=200};root.addView(logo);text("v${BuildConfig.VERSION_NAME} · Offline rental manager",14);val a=db.assets();val r=db.rentals();text("Assets: ${a.size}  |  Active: ${r.count{it.status=="ACTIVE"}}  |  Overdue: ${r.count{it.status=="ACTIVE"&&it.end<System.currentTimeMillis()}}",18);text("Collected rental fees: ${r.sumOf{it.fee}} Ks");button("Add rental asset",{addAsset()});button("Manage assets",{assets()});button("New booking",{book()});button("Rentals / Returns",{rentals()});button("Check for APK updates",{checkForUpdates()});button("View announcements",{showAnnouncements()});button("Enable notifications",{enableNotifications()})}
 private fun addAsset() {base("Add Asset");val n=input("Asset name / ID");val p=input("Daily rate (Ks)",true);button("Save",{val rate=p.text.toString().toLongOrNull();if(n.text.isBlank()||rate==null||rate<0)alert("Enter valid asset and rate") else {db.addAsset(n.text.toString().trim(),rate);assets()}})}
 private fun assets() {base("Assets");db.assets().forEach { a->text("${a.name} • ${a.rate} Ks/day • ${if(a.maintenance)"MAINTENANCE" else "AVAILABLE"}");button(if(a.maintenance)"Enable rental" else "Maintenance lock",{db.maintenance(a.id,!a.maintenance);assets()}) }}
 private fun book() {base("New Booking");val available=db.assets().filter{!it.maintenance};if(available.isEmpty()){text("Add an available asset first");return};val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,available.map{it.name});root.addView(spinner);val customer=input("Customer name");val phone=input("Phone");val start=input("Start: yyyy-MM-dd HH:mm");val end=input("End: yyyy-MM-dd HH:mm");val fee=input("Rental fee (Ks)",true);val deposit=input("Deposit (Ks)",true);val now=System.currentTimeMillis();start.setText(fmt.format(Date(now)));end.setText(fmt.format(Date(now+86400000)));button("Confirm booking",{try {val s=fmt.parse(start.text.toString())!!.time;val e=fmt.parse(end.text.toString())!!.time;val f=fee.text.toString().toLong();val d=deposit.text.toString().toLong();if(customer.text.isBlank()||phone.text.isBlank()) {alert("Customer and phone required");return@button};if(db.book(available[spinner.selectedItemPosition],customer.text.toString(),phone.text.toString(),s,e,f,d)){alert("Booking saved");rentals()}else alert("Unavailable: overlapping booking or maintenance")}catch(_:Exception){alert("Check date, fee and deposit")}})}
 private fun rentals() {base("Rental Records");db.rentals().forEach {r->text("#${r.id} ${r.asset} • ${r.status}\n${r.customer} (${r.phone})\n${fmt.format(Date(r.start))} → ${fmt.format(Date(r.end))}\nFee ${r.fee} Ks | Deposit ${r.deposit} Ks | Refunded ${r.refunded} Ks");if(r.status=="ACTIVE")button("Return & refund deposit #${r.id}",{AlertDialog.Builder(this).setTitle("Confirm return").setMessage("Mark returned and refund full deposit? Verify asset condition first.").setNegativeButton("Cancel",null).setPositiveButton("Confirm"){_,_->db.complete(r.id);rentals()}.show()})}}
 private fun enableNotifications() {
  if (Build.VERSION.SDK_INT >= 33 &&
      checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
   requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1003)
  } else alert("Notifications are enabled. Delivery depends on device connectivity and battery settings.")
 }

 private fun checkForUpdates() {
  alert("Checking release channel...")
  Thread {
   try {
    val feed = RentTrackUpdates.fetch()
    runOnUiThread {
     RentTrackUpdates.processFeed(this, feed)
     val release = feed.release
     if (release.versionCode > BuildConfig.VERSION_CODE && release.canInstall()) {
      AlertDialog.Builder(this).setTitle("RentTrack update ${release.versionName}")
       .setMessage((release.notes.ifBlank { "A newer release is ready." }) +
           "\n\nThe APK will be verified before Android asks to install it.")
       .setNegativeButton("Later", null)
       .setPositiveButton("Download & install") { _,_ -> downloadUpdate(release) }
       .show()
     } else if (release.versionCode > BuildConfig.VERSION_CODE) {
      AlertDialog.Builder(this).setTitle("New version pending")
       .setMessage("Release record exists but verified APK is not published yet.")
       .setPositiveButton("OK", null).show()
     } else {
      alert("You have the latest available RentTrack release (v${BuildConfig.VERSION_NAME}).")
     }
    }
   } catch (e: Exception) {
    runOnUiThread { alert("Could not check updates. Internet may be unavailable: ${e.message}") }
   }
  }.start()
 }

 private fun showAnnouncements() {
  alert("Loading announcements...")
  Thread {
   try {
    val feed=RentTrackUpdates.fetch()
    val body=if(feed.notices.isEmpty()) "No new announcements" else
       feed.notices.joinToString("\n\n") { "${it.title}\n${it.body}" }
    runOnUiThread {
     AlertDialog.Builder(this).setTitle("Future Code RentTrack • Notices")
      .setMessage(body).setPositiveButton("OK",null).show()
    }
   } catch(e:Exception) {runOnUiThread {alert("Notices unavailable while offline.")}}
  }.start()
 }

 private fun downloadUpdate(release:RentTrackUpdates.Release) {
  alert("Downloading APK over HTTPS. Please keep the app open.")
  Thread {
   try {
    val file=RentTrackUpdates.verifiedDownload(applicationContext,release)
    runOnUiThread { installVerifiedApk(file) }
   } catch (e:Exception) {
    runOnUiThread {
     AlertDialog.Builder(this).setTitle("Update stopped")
      .setMessage("Download or checksum verification failed: ${e.message}")
      .setPositiveButton("OK",null).show()
    }
   }
  }.start()
 }

 private fun installVerifiedApk(file:File) {
  if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
   pendingApk=file
   AlertDialog.Builder(this).setTitle("Allow Android installer")
    .setMessage("Android requires your permission to install updates from RentTrack. Grant permission, then return to RentTrack.")
    .setNegativeButton("Cancel",null)
    .setPositiveButton("Open settings") { _, _ ->
     startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
      Uri.parse("package:$packageName")))
    }.show()
   return
  }
  try {
   val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",file)
   startActivity(Intent(Intent.ACTION_VIEW).apply {
    setDataAndType(uri,"application/vnd.android.package-archive")
    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
   })
  } catch(e:Exception) {alert("Could not open Android installer: ${e.message}")}
 }

 override fun onResume() {
  super.onResume()
  val file=pendingApk
  if(file!=null && (! (Build.VERSION.SDK_INT>=26) || packageManager.canRequestPackageInstalls())) {
   pendingApk=null
   installVerifiedApk(file)
  }
 }

}
